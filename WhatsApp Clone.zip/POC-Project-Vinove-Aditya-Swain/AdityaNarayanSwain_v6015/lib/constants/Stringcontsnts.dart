class StringConstants {
//tabs
static String tab_1 = "CHATS";
static String tab_2 = "STATUS";
static String tab_3 = "CALL";

//menu items
static String tab2Item1 = "New group";
static String tab2Item2 = "New broadcast";
static String tab2Item3 = "Linked devices";
static String tab2Item4 = "Starred messages";
static String tab2Item5 = "Payments";
static String tab2Item6 = "Settings";

static String tab3Item1 = "Status privacy";
static String tab3Item2 = "Settings";

static String tab4Item1 = "Clear call log";
static String tab4Item2 = "Settings";
}
