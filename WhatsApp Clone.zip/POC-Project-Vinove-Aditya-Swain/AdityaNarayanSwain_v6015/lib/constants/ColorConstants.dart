import 'package:flutter/material.dart';
class AppColors {

  static const Color Teal_green = Color(0xFF128C7E);
  static const Color teal_dark_green = Color(0xFF075E54);
  static const Color light_geen = Color(0xFF25D366);
  static const Color Blue = Color(0xFF34B7F1);
  static const Color light_yellow = Color(0xFFDCF8C6);
  static const Color light_pink = Color(0xFFECE5DD);

}
