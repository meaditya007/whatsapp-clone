class Users{
  int phone;
  String name;

  Users({required this.name,required this.phone});
}