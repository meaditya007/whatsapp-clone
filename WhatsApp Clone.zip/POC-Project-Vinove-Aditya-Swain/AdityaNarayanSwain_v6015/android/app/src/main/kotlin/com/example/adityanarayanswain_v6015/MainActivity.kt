package com.example.adityanarayanswain_v6015

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
